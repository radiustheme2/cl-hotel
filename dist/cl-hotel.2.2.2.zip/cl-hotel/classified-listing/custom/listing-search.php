<?php

/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.5.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!class_exists('RtclPro')) return;

use Rtcl\Helpers\Functions;
use Rtcl\Resources\Options as RtclOptions;
use RadiusTheme\CLHotel\Options;

$classes = 'form-shortcode';

$loc_text = esc_attr__('Select Location', 'cl-hotel');
$cat_text = esc_attr__('Select Category', 'cl-hotel');


$selected_location = $selected_category = false;

if (get_query_var('rtcl_location') && $location = get_term_by('slug', get_query_var('rtcl_location'), rtcl()->location)) {
   $selected_location = $location;
}

if (get_query_var('rtcl_category') && $category = get_term_by('slug', get_query_var('rtcl_category'), rtcl()->category)) {
   $selected_category = $category;
}

$orderby = strtolower(Functions::get_option_item('rtcl_archive_listing_settings', 'taxonomy_orderby', 'name'));
$order = strtoupper(Functions::get_option_item('rtcl_archive_listing_settings', 'taxonomy_order', 'ASC'));

$banner_search_args = Options::$options['listing_banner_search_items'];
$style = '';

if (!empty($data['listing_banner_search_style'])) {
   $style = $data['listing_banner_search_style'];
} else {
   $style = Options::$options['listing_banner_search_style'];
}

$arr[] = 0;
foreach ($banner_search_args as $key => $value) {
   $arr[$value] = $value;
}

$search_items = array_filter($arr);
if (!empty($search_items)) {
   
?>

   <form action="<?php echo esc_url(Functions::get_filter_form_url()); ?>" class="form-vertical rtcl-widget-search-form rtcl-search-inline-form cl-hotel-listing-search-form rtin-style-<?php echo esc_attr($style[0]); ?>">
      <div class="inner-form-wrap">
         <?php if ($data['search_keyword'] == 'on' && isset($search_items['keyword']) &&  $search_items['keyword'] == 'keyword') { ?>
            <div class="btn-wrap">
               <div class="form-group">
                  <div class="rtcl-search-input-button rtin-keyword">
                     <input type="text" id="keyword" data-type="listing" name="q" class="rtcl-autocomplete" placeholder="<?php esc_attr_e('What are you looking for', 'cl-hotel'); ?>" value="<?php if (isset($_GET['q'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                        echo esc_attr( sanitize_text_field( wp_unslash( $_GET['q'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                     } ?>" />
                  </div>
               </div>
            </div>
         <?php }
         if ($data['search_location'] == 'on' && isset($search_items['location']) &&  $search_items['location'] == 'location') { ?>
            <?php if ('local' === Functions::location_type()) { ?>
               <div class="search-location">
                  <div class="form-group">
                     <?php if ($style == 'suggestion') : ?>
                        <div class="rtcl-search-input-button rtin-location">
                           <i class="demo-icon clr-icon-rt18-marker"></i>
                           <input type="text" data-type="location" class="rtcl-autocomplete rtcl-location" placeholder="<?php echo esc_attr('Write Location Name', 'cl-hotel'); ?>" value="<?php echo esc_attr($selected_location ? $selected_location->name : ''); ?>">
                           <input type="hidden" name="rtcl_location" value="<?php echo esc_attr($selected_location ? $selected_location->slug : ''); ?>">
                        </div>
                     <?php elseif ($style == 'standard') : ?>
                        <div class="rtcl-search-input-button rtin-location">
                           <i class="demo-icon clr-icon-rt18-marker"></i>
                           <?php
                              $loc_args = array(
                                 'show_option_none'  => $loc_text,
                                 'option_none_value' => '',
                                 'taxonomy'          => rtcl()->location,
                                 'name'              => 'rtcl_location',
                                 'id'                => 'rtcl-location-search-' . wp_rand(),
                                 'class'             => 'select2 form-control rtcl-location-search',
                                 'selected'          => get_query_var('rtcl_location'),
                                 'hierarchical'      => true,
                                 'value_field'       => 'slug',
                                 'depth'             => Functions::get_location_depth_limit(),
                                 'orderby'           => $orderby,
                                 'order'             => ('DESC' === $order) ? 'DESC' : 'ASC',
                                 'show_count'        => false,
                                 'hide_empty'        => false,
                              );
                              if ('_rtcl_order' === $orderby) {
                                 $args['orderby'] = 'meta_value_num';
                                 $args['meta_key'] = '_rtcl_order';
                              }
                              wp_dropdown_categories($loc_args);
                           ?>
                        </div>
                     <?php elseif ($style == 'dependency') : ?>
                        <div class="rtcl-search-input-button rtin-location">
                           <i class="demo-icon clr-icon-rt18-marker"></i>
                           <?php
                           Functions::dropdown_terms(array(
                              'show_option_none' => $loc_text,
                              'taxonomy'         => rtcl()->location,
                              'name'             => 'l',
                              'class'            => 'select2 form-control',
                              'selected'         => $selected_location ? $selected_location->term_id : 0
                           ));
                           ?>
                        </div>
                     <?php else : ?>
                        <div class="rtcl-search-input-button rtcl-search-input-location rtin-location">
                           <i class="demo-icon clr-icon-rt18-marker"></i>
                           <span class="search-input-label location-name">
                              <?php echo esc_html($selected_location ? $selected_location->name : $loc_text); ?>
                           </span>
                           <input type="hidden" class="rtcl-term-field" name="rtcl_location" value="<?php echo esc_attr($selected_location ? $selected_location->slug : ''); ?>">
                        </div>
                     <?php endif; ?>
                  </div>
               </div>
            <?php } else { ?>
               <?php 
               $rs_data = RtclOptions::radius_search_options();
               ?>
               <div class="search-location">
                  <div class="form-group">
                     <div class="rtcl-search-input-button rtin-location">
                        <input type="text" name="geo_address" autocomplete="off" value="<?php echo ! empty( $_GET['geo_address'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['geo_address'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>" placeholder="<?php esc_attr_e("Select a location", "cl-hotel"); ?>" class="form-control rtcl-geo-address-input" />
                        <i class="rtcl-get-location rtcl-icon rtcl-icon-target"></i>
                        <input type="hidden" class="latitude" name="center_lat" value="<?php echo ! empty( $_GET['center_lat'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['center_lat'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>">
                        <input type="hidden" class="longitude" name="center_lng" value="<?php echo ! empty( $_GET['center_lng'] ) ? esc_attr( sanitize_text_field( wp_unslash( $_GET['center_lng'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>">
                     </div>
                  </div>
               </div>
               <?php if (!empty(Options::$options['listing_search_items']['radius'])) { ?>
                  <div class="rt-mmm">
                     <div class="form-group">
                        <div class="rtcl-search-input-button rtin-radius">
                           <input type="number" class="form-control" name="distance" value="<?php echo ! empty( $_GET['distance'] ) ? absint( $_GET['distance'] ) : 30; // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>" placeholder="<?php esc_attr_e("Radius", "cl-hotel"); ?>">
                        </div>
                     </div>
                  </div>
               <?php } else { ?>
                  <input type="hidden" class="distance" name="distance" value="30">
               <?php } ?>
            <?php } ?>
         <?php } 
         if ($data['search_category'] == 'on' && isset($search_items['category']) &&  $search_items['category'] == 'category') { ?>
            <div class="search-cats">
               <div class="form-group">
                  <?php if ($style == 'suggestion') : ?>
                     <div class="rtcl-search-input-button rtin-category">
                        <i class="clr-icon-rt18-papper2-01"></i>
                        <input type="text" data-type="category" class="rtcl-autocomplete rtin-category" placeholder="<?php echo esc_attr('Write Category Name', 'cl-hotel'); ?>" value="<?php echo esc_attr($selected_category ? $selected_category->slug : ''); ?>">
                        <input type="hidden" name="rtcl_category" value="<?php echo esc_attr($selected_category ? $selected_category->slug : ''); ?>">
                     </div>
                  <?php elseif ($style == 'standard') : ?>
                     <div class="rtcl-search-input-button rtin-category">
                        <i class="clr-icon-rt18-papper2-01"></i>
                        <?php
                        $cat_args = array(
                           'show_option_none'  => $cat_text,
                           'option_none_value' => '',
                           'taxonomy'          => rtcl()->category,
                           'name'              => 'rtcl_category',
                           'id'                => 'rtcl-category-search-' . wp_rand(),
                           'class'             => 'select2 form-control rtcl-category-search',
                           'selected'          => get_query_var('rtcl_category'),
                           'hierarchical'      => true,
                           'value_field'       => 'slug',
                           'depth'             => Functions::get_category_depth_limit(),
                           'orderby'           => $orderby,
                           'order'             => ('DESC' === $order) ? 'DESC' : 'ASC',
                           'show_count'        => false,
                           'hide_empty'        => false,
                        );
                        if ('_rtcl_order' === $orderby) {
                           $args['orderby'] = 'meta_value_num';
                           $args['meta_key'] = '_rtcl_order';
                        }
                        wp_dropdown_categories($cat_args);
                        ?>
                     </div>
                  <?php elseif ($style == 'dependency') : ?>
                     <div class="rtcl-search-input-button rtin-category">
                        <i class="clr-icon-rt18-papper2-01"></i>
                        <?php
                        Functions::dropdown_terms(array(
                           'show_option_none'  => $cat_text,
                           'option_none_value' => -1,
                           'taxonomy'          => rtcl()->category,
                           'name'              => 'c',
                           'class'             => 'select2 form-control rtcl-category-search',
                           'selected'          => $selected_category ? $selected_category->term_id : 0
                        ));
                        ?>
                     </div>
                  <?php else : ?>
                     <div class="rtcl-search-input-button rtcl-search-input-category rtin-category">
                        <i class="clr-icon-rt18-papper2-01"></i>
                        <span class="search-input-label category-name">
                           <?php echo esc_html($selected_category ? $selected_category->name : $cat_text); ?>
                        </span>
                        <input type="hidden" name="rtcl_category" class="rtcl-term-field" value="<?php echo esc_attr($selected_category ? $selected_category->slug : ''); ?>">
                     </div>
                  <?php endif; ?>
               </div>
            </div>
         <?php } ?>

         <div class="rtin-btn-holder">
            <div class="form-group">
               <button type="submit" class="rtin-search-btn rdtheme-button-1 btn">
                  <?php esc_html_e('Search', 'cl-hotel'); ?>
                  <i class="demo-icon rt-custom-icon-rt18-search"></i>
               </button>
            </div>
         </div>
      </div>
   </form>
<?php } ?>